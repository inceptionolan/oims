import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hellow',
  templateUrl: './hellow.component.html',
  styleUrls: ['./hellow.component.css']
})
export class HellowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
